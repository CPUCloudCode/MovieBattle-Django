from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.template import loader

# Create your views here.
def index(request):
    
    template = loader.get_template('polls/index.html')
    return HttpResponse(template.render({}, request))

def instruction(request):
    
    template = loader.get_template('polls/instruction.html')
    return HttpResponse(template.render({}, request))
